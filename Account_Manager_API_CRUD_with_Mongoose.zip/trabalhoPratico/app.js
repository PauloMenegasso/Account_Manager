import express from 'express';
import { accountRouter } from './routes/accountRouter.js';
import mongoose from 'mongoose';

(async () => {
  try {
    await mongoose.connect(
      'mongodb+srv://Paulo:paulo@bootcampigti.xo6yx.mongodb.net/TrabalhoPratico?retryWrites=true&w=majority',
      {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      }
    );
    console.log('Conectado com sucesso ao Mongo Atlas');
  } catch (error) {
    console.log('Erro ao conectar ao MongoDB' + error);
  }
})();

const app = express();

app.use(express.json());
app.use(accountRouter);

app.listen(3001, () => console.log('API iniciada'));
