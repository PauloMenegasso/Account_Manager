import express from 'express';
import { accountModel } from '../modules/accountModel.js';

const app = express();
//consulta o saldo da conta
app.get('/account/saldo/:agencia/:conta/', async (req, res) => {
  try {
    const agencia = req.params.agencia;
    const conta = req.params.conta;
    const account = await accountModel.find({ conta: conta }, (err, obj) => {
      try {
        const name = obj[0].name;
        const valor = obj[0].balance;
        res.send(
          'O saldo da conta ' +
            conta +
            ', pertencente à ' +
            name +
            'é de ' +
            valor
        );
      } catch (error) {
        res.status(500).send('erro ao encontrar a conta');
      }
      // console.log(obj)
    });
  } catch (error) {
    const message = 'Erro ao realizar a consulta';
    res.status(500).send(message);
  }
});
//registra um depósito na conta
app.patch('/account/deposito/:agencia/:conta/:value', async (req, res) => {
  try {
    const agencia = req.params.agencia;
    const conta = req.params.conta;
    const valor = parseInt(req.params.value);
    const account = await accountModel.find({ conta: conta }, (err, obj) => {
      try {
        const valorAntigo = obj[0].balance;
        obj[0].balance += valor;
        obj[0].save();

        res.send(
          'Valor adicionado com sucesso. O novo valor é:' +
            obj[0].balance +
            'O valor antigo era: ' +
            valorAntigo
        );
      } catch (error) {
        res.status(500).send('erro ao encontrar a conta');
      }
      // console.log(obj)
    });
  } catch (error) {
    const message = 'Erro: Esta conta não existe';
    res.status(500).send(message);
  }
});

//registra um saque na conta
app.patch('/account/saque/:agencia/:conta/:value', async (req, res) => {
  try {
    const agencia = req.params.agencia;
    const conta = req.params.conta;
    const valor = parseInt(req.params.value);
    const account = await accountModel.find({ conta: conta }, (err, obj) => {
      try {
        const valorAntigo = obj[0].balance;
        if (valorAntigo > valor) {
          obj[0].balance -= valor + 1;
          obj[0].save();

          res.send(
            'Valor sacado com sucesso. O novo valor é:' +
              obj[0].balance +
              'O valor antigo era: ' +
              valorAntigo
          );
        } else {
          res.send('Valor Indisponível para saque');
        }
      } catch (error) {
        res.status(500).send('erro ao encontrar a conta');
      }
      // console.log(obj)
    });
  } catch (error) {
    const message = 'Erro: Esta conta não existe';
    res.status(500).send(message);
  }
});

//Excluir uma conta
app.delete('/account/excluir/:agencia/:conta/', async (req, res) => {
  try {
    const agencia = req.params.agencia;
    const conta = req.params.conta;
    const account = await accountModel.deleteOne(
      { conta: conta },
      async (err, obj) => {
        const message = 'Conta excluída com sucesso!';
        const remainAccounts = await accountModel.find(
          { agencia: agencia },
          (err, obj) => {
            res.send(
              message +
                '. A agência ' +
                agencia +
                ' ainda possui ' +
                obj.length +
                ' contas ativas.'
            );
          }
        );
      }
    );
  } catch (error) {
    const message = 'Erro: Esta conta não existe';
    res.status(500).send(message);
  }
});

//registra uma transferência entre contas
app.patch(
  '/account/transferencia/:contaOrigen/:contaDestino/:value',
  async (req, res) => {
    try {
      const contaOrigen = req.params.contaOrigen;
      const contaDestino = req.params.contaDestino;
      const valor = parseInt(req.params.value);
      if (contaDestino == contaOrigen) {
        res.send('Favor informar contas diferentes');
      } else {
        const account = await accountModel.find(
          { conta: contaOrigen },
          async (err, obj) => {
            const account2 = await accountModel.find(
              { conta: contaDestino },
              (err2, obj2) => {
                if (obj[0].agencia == obj2[0].agencia) {
                  //          console.log('mesma agencia detectada');
                  if (valor > obj[0].balance) {
                    res.send(
                      'Saldo na conta origen é insuficiente para transação'
                    );
                  } else {
                    obj[0].balance -= valor;
                    obj2[0].balance += valor;
                    obj[0].save();
                    obj2[0].save();
                    res.send(
                      'valor atual na conta de origen:' + obj[0].balance
                    );
                  }
                } else {
                  //          console.log('agencias diferentes detectadas');
                  if (valor + 8 > obj[0].balance) {
                    res.send(
                      'Saldo na conta origen é insuficiente para transação'
                    );
                  } else {
                    obj[0].balance -= valor + 8;
                    obj2[0].balance += valor;
                    obj[0].save();
                    obj2[0].save();
                    res.send(
                      'valor atual na conta de origen:' + obj[0].balance
                    );
                  }
                }
              }
            );
          }
        );
      }
    } catch (error) {
      const message = 'Erro: Esta conta não existe';
      res.status(500).send(message);
    }
  }
);

//Média dos saldos na agencia
app.get('/account/media/:agencia', async (req, res) => {
  const agencia = req.params.agencia;
  const agregado = await accountModel.find({ agencia: agencia }, (err, obj) => {
    let somatorio = 0;
    let numero = 0;
    const media = obj.forEach((element) => {
      somatorio += element.balance;
      numero += 1;
    });
    res.send(
      'A média do saldo nas contas desta agência é ' + somatorio / numero
    );
  });
});

//Menores saldos
app.get('/account/menoresSaldos/:numero', async (req, res) => {
  const numero = req.params.numero;
  const agregado = await accountModel.find({}, (err, obj) => {
    const orderedList = obj.sort(function (a, b) {
      if (a.balance > b.balance) {
        return 1;
      }
      if (a.balance < b.balance) {
        return -1;
      }
      // a must be equal to b
      return 0;
    });
    res.send(orderedList.slice(0, numero));
  });
});

//Maiores saldos
app.get('/account/maioresSaldos/:numero', async (req, res) => {
  const numero = req.params.numero;
  const agregado = await accountModel.find({}, (err, obj) => {
    const orderedList = obj.sort(function (a, b) {
      if (a.balance > b.balance) {
        return -1;
      }
      if (a.balance < b.balance) {
        return 1;
      }
      // a must be equal to b
      return 0;
    });
    res.send(orderedList.slice(0, numero));
  });
});

//transferência entre agencias
app.patch('/account/agencia99/', async (req, res) => {
  const richpeople = [];
  await getRicherPerson(richpeople, 10);
  await getRicherPerson(richpeople, 25);
  await getRicherPerson(richpeople, 33);
  await getRicherPerson(richpeople, 47);
  await getRicherPerson(richpeople, 10);
  res.send(richpeople);
});

async function getRicherPerson(richpeople, agencia) {
  const account = await accountModel.find({ agencia: agencia }, (err, obj) => {
    const orderedList = obj.sort(function (a, b) {
      if (a.balance > b.balance) {
        return -1;
      }
      if (a.balance < b.balance) {
        return 1;
      }
      // a must be equal to b
      return 0;
    });
    richpeople.push(orderedList[0]);
  });
}

export { app as accountRouter };
